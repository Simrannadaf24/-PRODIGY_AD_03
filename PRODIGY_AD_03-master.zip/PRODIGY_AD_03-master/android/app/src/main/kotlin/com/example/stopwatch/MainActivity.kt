package com.example.stopwatch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
